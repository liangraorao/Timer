package com.naman14.timber.lastfmapi.callbacks;



/**
 * Created by christoph on 17.07.16.
 */
public interface UserListener {
    void userSuccess();

    void userInfoFailed();

}
